"use client"

import Link from "next/link"
import { Crosshair, LayoutTemplate, ArrowRight } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-[#F6F6F4]">
      {/* Header */}
      <header className="flex items-center justify-between px-8 py-6 md:px-12 lg:px-20">
        <Link href="/dashboard" className="group flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full border border-[#296167]/30 bg-[#296167]/5">
            <span className="font-serif text-lg text-[#296167]">M</span>
          </div>
          <span className="font-serif text-xl tracking-wide text-[#2A2420]">
            MaRe <span className="text-[#296167]">Signal</span>
          </span>
        </Link>
        <div className="flex items-center gap-4">
          <div className="hidden text-right sm:block">
            <p className="font-sans text-sm font-medium text-[#2A2420]">Rebecca Chen</p>
            <p className="font-sans text-xs text-[#3B3632]/70">Growth Lead</p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#296167] text-sm font-medium text-white">
            RC
          </div>
        </div>
      </header>

      {/* Subtle divider */}
      <div className="mx-8 h-px bg-gradient-to-r from-transparent via-[#E2E2DE] to-transparent md:mx-12 lg:mx-20" />

      {/* Main Content */}
      <main className="flex flex-col items-center justify-center px-6 py-16 md:py-24 lg:py-32">
        {/* Hero Section */}
        <div className="mb-16 text-center md:mb-20 lg:mb-24">
          <p className="mb-4 font-sans text-xs font-medium uppercase tracking-[0.2em] text-[#296167]">
            Partner Acquisition Platform
          </p>
          <h1 className="font-serif text-4xl tracking-tight text-[#2A2420] md:text-5xl lg:text-6xl">
            <span className="text-balance">Discover Your Next</span>
            <br />
            <span className="text-[#296167]">Luxury Partner</span>
          </h1>
          <p className="mx-auto mt-6 max-w-lg font-sans text-base leading-relaxed text-[#3B3632] md:mt-8 md:text-lg">
            Identify high-value salon partners and deploy personalized outreach campaigns that convert.
          </p>
        </div>

        {/* Navigation Cards */}
        <div className="grid w-full max-w-5xl gap-6 md:grid-cols-2 md:gap-8 lg:gap-10">
          {/* Card 1: Salon Prospector */}
          <Link
            href="/dashboard/prospector"
            className="group relative overflow-hidden rounded-lg border border-[#E2E2DE] bg-white p-8 transition-all duration-500 hover:border-[#296167]/30 hover:shadow-[0_8px_40px_-12px_rgba(41,97,103,0.15)] md:p-10 lg:p-12"
          >
            {/* Subtle background accent on hover */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#296167]/[0.02] to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
            
            <div className="relative">
              <div className="mb-8 flex items-start justify-between">
                <div className="flex h-14 w-14 items-center justify-center rounded-lg border border-[#E2E2DE] bg-[#F6F6F4] transition-all duration-500 group-hover:border-[#296167]/30 group-hover:bg-[#296167]/5">
                  <Crosshair className="h-6 w-6 text-[#296167]" strokeWidth={1.5} />
                </div>
                <div className="flex h-8 w-8 items-center justify-center rounded-full border border-[#E2E2DE] opacity-0 transition-all duration-500 group-hover:opacity-100 group-hover:border-[#296167]/30">
                  <ArrowRight className="h-4 w-4 text-[#296167] transition-transform duration-300 group-hover:translate-x-0.5" strokeWidth={1.5} />
                </div>
              </div>
              
              <h2 className="font-serif text-2xl text-[#2A2420] transition-colors duration-300 group-hover:text-[#296167] md:text-3xl">
                Salon Prospector
              </h2>
              <p className="mt-4 font-sans text-sm leading-relaxed text-[#3B3632] md:text-base">
                Discover, enrich, and score $1M+ luxury salon partners with AI-powered intelligence.
              </p>
              
              {/* Stats preview */}
              <div className="mt-8 flex items-center gap-6 border-t border-[#E2E2DE]/60 pt-6">
                <div>
                  <p className="font-serif text-2xl text-[#296167]">847</p>
                  <p className="font-sans text-xs text-[#3B3632]/70">Prospects</p>
                </div>
                <div className="h-8 w-px bg-[#E2E2DE]" />
                <div>
                  <p className="font-serif text-2xl text-[#296167]">12</p>
                  <p className="font-sans text-xs text-[#3B3632]/70">Hot Leads</p>
                </div>
              </div>
            </div>
          </Link>

          {/* Card 2: Marketing Engine */}
          <Link
            href="/dashboard/marketing"
            className="group relative overflow-hidden rounded-lg border border-[#E2E2DE] bg-white p-8 transition-all duration-500 hover:border-[#296167]/30 hover:shadow-[0_8px_40px_-12px_rgba(41,97,103,0.15)] md:p-10 lg:p-12"
          >
            {/* Subtle background accent on hover */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#296167]/[0.02] to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
            
            <div className="relative">
              <div className="mb-8 flex items-start justify-between">
                <div className="flex h-14 w-14 items-center justify-center rounded-lg border border-[#E2E2DE] bg-[#F6F6F4] transition-all duration-500 group-hover:border-[#296167]/30 group-hover:bg-[#296167]/5">
                  <LayoutTemplate className="h-6 w-6 text-[#296167]" strokeWidth={1.5} />
                </div>
                <div className="flex h-8 w-8 items-center justify-center rounded-full border border-[#E2E2DE] opacity-0 transition-all duration-500 group-hover:opacity-100 group-hover:border-[#296167]/30">
                  <ArrowRight className="h-4 w-4 text-[#296167] transition-transform duration-300 group-hover:translate-x-0.5" strokeWidth={1.5} />
                </div>
              </div>
              
              <h2 className="font-serif text-2xl text-[#2A2420] transition-colors duration-300 group-hover:text-[#296167] md:text-3xl">
                Marketing Engine
              </h2>
              <p className="mt-4 font-sans text-sm leading-relaxed text-[#3B3632] md:text-base">
                Review AI-drafted outreach and approve personalized microsites for each prospect.
              </p>
              
              {/* Stats preview */}
              <div className="mt-8 flex items-center gap-6 border-t border-[#E2E2DE]/60 pt-6">
                <div>
                  <p className="font-serif text-2xl text-[#296167]">23</p>
                  <p className="font-sans text-xs text-[#3B3632]/70">Pending</p>
                </div>
                <div className="h-8 w-px bg-[#E2E2DE]" />
                <div>
                  <p className="font-serif text-2xl text-[#296167]">156</p>
                  <p className="font-sans text-xs text-[#3B3632]/70">Sent</p>
                </div>
              </div>
            </div>
          </Link>
        </div>

        {/* Subtle footer text */}
        <p className="mt-16 font-sans text-xs text-[#3B3632]/50 md:mt-20">
          MaRe Luxury Head Spa — Where Science Meets Serenity
        </p>
      </main>
    </div>
  )
}
